# **Restaurant Landing Page**

A sleek and modern landing page for a fictional restaurant, based on a [Dribbble design](https://dribbble.com/shots/12998351-Food-Mobile-APP-Landing-UX-UI-Design) by Ghulam Rasool. I developed this project as a way to test my ability to replicate a design image into a functional HTML/CSS website. Despite being an old project, I have chosen to keep this as a portfolio piece as it represents some of my earliest work.

![Screenshot](images/preview.png)
